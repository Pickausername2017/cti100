<html>
<body>

Thank You For Registering <?php echo $_GET["name"]; ?><br>
Additional Updates will be sent to your Email Address: <?php echo $_GET["email"]; ?>

</body>
</html>